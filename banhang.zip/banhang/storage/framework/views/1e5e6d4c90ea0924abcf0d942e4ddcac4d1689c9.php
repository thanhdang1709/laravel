<?php $__env->startSection('content'); ?>

<h1 style="text-align: center;margin-top: 20px;margin-bottom: 20px;">Bảng báo giá</h1>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>