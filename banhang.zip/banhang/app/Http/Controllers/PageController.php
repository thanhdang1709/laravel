<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Slide;
use App\Product;
use App\ProductType;
use App\Cart;
use Session;
use App\Customer;
use App\Bill;
use App\BillDetail;
use Hash;


use App\User;
class PageController extends Controller
{
    public function getIndex(){
    	$slide = Slide::all();
    	$new_product = Product::where('new',1)->paginate(50);



    	return view('trangchu',compact('slide','new_product'));
    }

    public function getBaogia(){

        return view('baogia');
    }

    public function getloaiSp($type){

    	$sp_theoloai = Product::where('id_type',$type)->get();
    	$loaisp     = ProductType::all();
    	$spkhac = Product::where('id_type','<>',$type)->paginate(6);
    	$tenloai=Product::where('id',$type)->first();
        $loai = ProductType::where('id',$type)->first();
    	return view('loai_sanpham', compact('sp_theoloai','loaisp','spkhac','tenloai','loai'));
    }

    public function getchitietSp($id){
        $new_product = Product::where('new',1)->paginate(12);
    	$chitietsp = Product::where('id',$id)->first();
        $spkhac = Product::where('id_type','<>',$id)->paginate(6);
    	return view('chitiet',compact('chitietsp','spkhac','new_product'));
    }
    public function getlienhe(){

    	return view('contact');
    }

    public function getgioithieu(){

    	return view('gioithieu');
   	}

    public function getAddtoCart(Request $req, $id){
        $product = Product::find($id);
        $oldCart = Session('cart')?Session::get('cart'):null;
        $cart = new Cart($oldCart); 
        $cart->add($product,$id);
        $req->session()->put('cart',$cart);
        return redirect()->back();

    }

    public function getDeItemCart($id){

        $oldCart = Session::has('cart')?Session::get('cart'):null;
        $cart = new Cart($oldCart);
        $cart -> removeItem($id);

        if(count($cart->items)>0){
            Session::put('cart',$cart);
        }   
        else{
            Session::forget('cart');
        }
        return redirect()->back();
    }

    public function getCheckOut(){

        return view('checkout');
    }




    public function postCheckout(Request $req){

        $Cart = Session::get('cart');
       // dd($Cart);

        $customer = new Customer;
        $customer->name = $req->name;
        $customer->gender = $req->gender;
        $customer->email = $req->email;
        $customer->address = $req->Address;
        $customer->phone_number = $req->phone;
        $customer->note = $req->notes;

        $customer->save();  


        $bill = new Bill;
        $bill->id_customer = $customer->id;
        $bill->date_order = date('Y-m-d');
        $bill->total = $Cart->totalPrice;
        $bill->payment =  $req->payment;
        $bill->note = $req->notes;
        $bill->save();


        foreach ($Cart->items as $key => $value){
        $billdetail = new BillDetail;
        $billdetail->id_bill = $bill->id;
        $billdetail->id_product = $key;
        $billdetail->quantity = $value['qty'];
        $billdetail->unit_price =($value['price']/$value['qty']);
        $billdetail->save();
           }
        Session::forget('cart');
        return redirect('index');
    }


    public function login(){

        return view('login');
    }

    public function register(){

        return view('register');
    }


    public function postSignup(Request $req){
        $this->validate($req,[

                'email'=>'required|email|unique:user,email',
                'password'=>'required|min:6|max:20',
                'fullname'=>'required',
                're_password'=>'required|same:password'
            ],
            [
                'email.required'=>'Vui long nhap email',
                'email.email'=>'Khong dung email',
                'email.unique'=>'Trung email',
                'password.required'=>'Vui long nhap mat khau',
                're_password.same'=>'Mat khau khong trung khop',
                'password.min'=>'Mat khau it nhat 6 ki tu'


            ]);
        $user = new User();

        $user->full_name = $req->fullname;
        $user->email = $req->email;
        $user->password = Hass::make($req->password);
        $user->phone = $req->phone;
        $user->address = $req->address;
        $user->save();
        return redirect()->back()->with('thanhcong','Dang ki thanh cong');



    }




    public function getSearch(Request $req){


        $product = Product::where('name','like','%'.$req->search.'%')->get();

        return view('Search',compact('product'));




    }
}
