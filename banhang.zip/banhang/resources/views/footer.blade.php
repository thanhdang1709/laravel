
	<div id="footer" class="color-div">
		<div class="container">
			<div class="row">
				<div class="col-sm-3">
					<div class="widget">
						<h4 class="widget-title">Bản đồ	</h4>
						<div id="map"><div></div></div>
					</div>
				</div>
				<div class="col-sm-2">
					<div class="widget">
						<h4 class="widget-title">Liên kết</h4>
						<div>
							<ul>
								<li><a href="#"><i class="fa fa-chevron-right"></i> Hình thức mua hàng</a></li>
								<li><a href="#"><i class="fa fa-chevron-right"></i> Hướng dẫn thanh toán</a></li>
								<li><a href="#"><i class="fa fa-chevron-right"></i>Quy định đổi trả</a></li>
							</ul>
						</div>
					</div>
				</div>
				<div class="col-sm-4">
				 <div class="col-sm-10">
					<div class="widget">
						<h4 class="widget-title">Liên hệ</h4>
						<div>
							<div class="contact-info">
								<i class="fa fa-map-marker"></i>
								<p>210/11 Nguyễn Thị Thập, Phường Bình Thuận Quận 7</p>
							</div>
						</div>
					</div>
				  </div>
				</div>
				<div class="col-sm-3">
					<div class="widget">
						<h4 class="widget-title">Nhận email</h4>
						<form action="#" method="post">
							<input type="email" name="your_email">
							<button class="pull-right" type="submit">Đăng kí <i class="fa fa-chevron-right"></i></button>
						</form>
					</div>
				</div>
			</div> <!-- .row -->
		</div> <!-- .container -->
	</div> <!-- #footer -->