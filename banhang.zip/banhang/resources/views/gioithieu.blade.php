@extends('master')
@section('content')


				<h6 class="inner-title" style="text-align: center;margin:10px 10px;">Giới thiệu</h6>

			
@endsection