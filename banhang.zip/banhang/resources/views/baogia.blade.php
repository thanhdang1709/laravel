@extends('master')

@section('content')

<h1 style="text-align: center;margin-top: 20px;margin-bottom: 20px;">Bảng báo giá</h1>

@endsection