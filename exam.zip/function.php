<?php



mysql_connect('localhost','root','');
mysql_select_db('examo');




session_start();

function get_user($user,$pass){


$sql = mysql_query("select * from user where user='$user' and pass='$pass' ");

if(mysql_num_rows($sql)>0)
{

	$row = mysql_fetch_array($sql);
	$_SESSION['currUser']=$row['user'];

	if($row['role']==1)
	{
		$_SESSION['currAdmin']=$row['role'];
		header("location: dashboard.php");
	} 
	if($row['role']==2)
	{
		header("location: index.php");
	}


}
else 
{
	echo "<script>alert('dang nhap sai')</script> ";
}

}

function reg_user($reguser,$regpass,$role){

		$sql = mysql_query("insert into user (user,pass,role) value('$reguser','$regpass','$role') ");

}


?>
