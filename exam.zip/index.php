<?php

require("function.php");
if(!isset($_SESSION['currUser'])){
	header('location: login.php');
}

?>




<!DOCTYPE html><html class=''>
<head>
<title>THPC Vĩnh Trạch</title>
<link rel='stylesheet prefetch' href='https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css'>
<style class="cp-pen-styles">@import url(https://fonts.googleapis.com/css?family=Nunito:400,300,700);
* {
  box-sizing: border-box;
}

.cp {
  background: #3C3F44 !important;
  border: none !important;
}
.cp a {
  text-decoration: none;
  color: white;
}

.tw {
  background: #34B1EC !important;
  border: none !important;
  color: white !important;
}
.tw a {
  text-decoration: none;
  color: white;
}

.fb {
  background: #4057AB !important;
  border: none !important;
}
.fb a {
  text-decoration: none;
  color: white;
}

.null {
  border: none !important;
}
.null .planets_container__quiz .planet_answer:nth-of-type(1) {
  display: block !important;
}
.null .planet_answer img {
  -webkit-transform: scale(1) !important;
          transform: scale(1) !important;
}

body {
  margin: 0;
  font-family: 'nunito';
  padding: 0;
  height: 100vh;
}
body .tick {
  color: #76E693;
  position: absolute;
  top: 8px;
  left: 0;
  -webkit-transform: scale(0);
          transform: scale(0);
  right: 0;
  -webkit-animation: tick .3s forwards;
          animation: tick .3s forwards;
  font-size: 20px;
}
body .timer {
  color: white;
  position: absolute;
  top: 20px;
  font-weight: 400;
  font-size: 13px;
  right: 20px;
  z-index: 10;
}
body .overlay {
  display: none;
  width: 100%;
  opacity: 0.9;
  position: fixed;
  height: 100%;
  z-index: 1;
  background: #1D1F29;
}
body .winner {
  display: none;
}
body .intro {
  display: none;
}
body .modal {
  z-index: 2;
  width: 400px;
  background: white;
  left: 0;
  border-radius: 12px;
  right: 0;
  position: absolute;
  top: 50%;
  -webkit-transform: translateY(-50%);
          transform: translateY(-50%);
  margin: auto;
}
body .modal_inner {
  padding: 30px;
  text-align: center;
}
body .modal_inner img {
  width: 100%;
}
body .modal_inner button {
  border: 2px solid #E14122;
  background: none;
  color: #E14122;
  font-weight: 700;
  font-family: 'nunito';
  padding: 10px 13px;
  outline: none;
  cursor: pointer;
  margin-top: 20px;
  border-radius: 4px;
  -webkit-transition: all .2s;
  transition: all .2s;
}
body .modal_inner button:hover {
  background: #E14122;
  color: white;
}
body .modal_inner h2 {
  margin: 0;
  color: #E14122;
}
body .modal_inner p {
  color: #5C5E67;
  font-weight: 100;
  font-size: 14px;
}
body .modal_inner__close {
  position: absolute;
  right: -20px;
  top: -20px;
  color: white;
  cursor: pointer;
  opacity: 0.6;
  -webkit-transition: all .3s;
  transition: all .3s;
}
body .modal_inner__close:hover {
  opacity: 1;
}
body .ui-state-hover {
  border: 2px dashed #11DFF3 !important;
  box-shadow: 0px 0px 20px 0px rgba(52, 205, 224, 0.11);
  -webkit-transform: scale(1.2) !important;
          transform: scale(1.2) !important;
}
body .ui-state-hover span {
  color: #11DFF3 !important;
}
body .planets {
  overflow: hidden;
  background: -webkit-linear-gradient(left, #262D48 0%, #0A0B0E 100%);
  background: linear-gradient(90deg, #262D48 0%, #0A0B0E 100%);
  width: 100%;
  height: 100vh;
  position: relative;
}
body .planets_stars {
  background-size: 400px;
  background-repeat: repeat;
  position: absolute;
  width: 100%;
  height: 100%;
  background-image: url("https://s3-us-west-2.amazonaws.com/s.cdpn.io/217233/stars-back.png");
}
body .planets_stars img {
  width: 100%;
}
body .planets_container {
  width: 1000px;
  text-align: center;
  height: 520px;
  position: absolute;
  left: 0;
  right: 0;
  margin: auto;
  top: 50%;
  -webkit-transform: translateY(-50%);
          transform: translateY(-50%);
}
body .planets_container__title h1 {
  margin: 0;
  color: white;
}
body .planets_container__title h3 {
  margin: 0;
  color: #E14122;
  font-weight: 400;
}
body .planets_container__planets {
  margin: 90px;
}
body .planets_container__planets .answered {
  opacity: 0.3;
}
body .planets_container__planets span {
  color: #ef4423;
  font-size: 13px;
  display: block;
  margin-top: 7px;
}
body .planets_container__planets .planet_wrap {
  display: inline-block;
  width: 75px;
}
body .planets_container__planets .info {
  background: white;
  width: 100px;
  height: 100px;
  display: none;
}
body .planets_container__planets .planet {
  border-radius: 100px;
  cursor: pointer;
}
body .planets_container__planets .planet img {
  height: 38px;
  position: relative;
  z-index: 11;
  border-radius: 100px;
}
body .planets_container__quiz .planet_holder {
  width: 40px;
  -webkit-transition: all .3s;
  transition: all .3s;
  height: 40px;
  border-radius: 100px;
  display: inline-block;
  border: 2px dashed rgba(255, 255, 255, 0.22);
  margin-right: 30px;
}
body .planets_container__quiz .planet_holder span {
  position: absolute;
  left: 0;
  right: 0;
  color: white;
  top: 50%;
  -webkit-transition: all .3s;
  transition: all .3s;
  -webkit-transform: translateY(-50%);
          transform: translateY(-50%);
}
body .planets_container__quiz .sun {
  width: 160px;
  height: 156px;
  position: relative;
  top: 30px;
  -webkit-animation: space_wobble 5.8s .1s linear infinite;
          animation: space_wobble 5.8s .1s linear infinite;
}
body .planets_container__quiz .sun span {
  font-size: 50px;
}
body .planets_container__quiz .mercury {
  width: 30px;
  height: 30px;
  position: relative;
  top: -60px;
  -webkit-animation: space_wobble 5.7s .4s linear infinite;
          animation: space_wobble 5.7s .4s linear infinite;
}
body .planets_container__quiz .mercury span {
  font-size: 10px;
}
body .planets_container__quiz .venus {
  width: 40px;
  height: 40px;
  position: relative;
  top: -20px;
  -webkit-animation: space_wobble 5.3s .8s linear infinite;
          animation: space_wobble 5.3s .8s linear infinite;
}
body .planets_container__quiz .venus span {
  font-size: 12px;
}
body .planets_container__quiz .earth {
  width: 50px;
  height: 50px;
  position: relative;
  top: -30px;
  -webkit-animation: space_wobble 5.2s 1s linear infinite;
          animation: space_wobble 5.2s 1s linear infinite;
}
body .planets_container__quiz .earth span {
  font-size: 20px;
}
body .planets_container__quiz .mars {
  width: 46px;
  height: 46px;
  position: relative;
  -webkit-animation: space_wobble 5s .1s linear infinite;
          animation: space_wobble 5s .1s linear infinite;
}
body .planets_container__quiz .mars span {
  font-size: 18px;
}
body .planets_container__quiz .jupiter {
  width: 90px;
  height: 90px;
  position: relative;
  top: -10px;
  -webkit-animation: space_wobble 4.7s .6s linear infinite;
          animation: space_wobble 4.7s .6s linear infinite;
}
body .planets_container__quiz .jupiter span {
  font-size: 30px;
}
body .planets_container__quiz .saturn {
  width: 80px;
  height: 80px;
  position: relative;
  top: 20px;
  -webkit-animation: space_wobble 5.9s .1s linear infinite;
          animation: space_wobble 5.9s .1s linear infinite;
}
body .planets_container__quiz .saturn span {
  font-size: 26px;
}
body .planets_container__quiz .uranus {
  width: 50px;
  height: 50px;
  position: relative;
  top: -30px;
  -webkit-animation: space_wobble 6s .7s linear infinite;
          animation: space_wobble 6s .7s linear infinite;
}
body .planets_container__quiz .uranus span {
  font-size: 20px;
}
body .planets_container__quiz .neptune {
  width: 47px;
  height: 47px;
  position: relative;
  top: -10px;
  -webkit-animation: space_wobble 5s .4s linear infinite;
          animation: space_wobble 5s .4s linear infinite;
}
body .planets_container__quiz .scale {
  -webkit-transform: scale(1) !important;
          transform: scale(1) !important;
}
body .planets_container__quiz .planet_answer {
  border-radius: 100px;
}
body .planets_container__quiz .planet_answer img {
  width: 100%;
  -webkit-transform: scale(0);
          transform: scale(0);
  -webkit-transition: all .3s;
  transition: all .3s;
}

@-webkit-keyframes space_wobble {
  0% {
    -webkit-transform: translateY(0px);
            transform: translateY(0px);
  }
  25% {
    -webkit-transform: translateY(3px);
            transform: translateY(3px);
  }
  50% {
    -webkit-transform: translateY(0px);
            transform: translateY(0px);
  }
  75% {
    -webkit-transform: translateY(-3px);
            transform: translateY(-3px);
  }
  100% {
    -webkit-transform: translateY(0px);
            transform: translateY(0px);
  }
}

@keyframes space_wobble {
  0% {
    -webkit-transform: translateY(0px);
            transform: translateY(0px);
  }
  25% {
    -webkit-transform: translateY(3px);
            transform: translateY(3px);
  }
  50% {
    -webkit-transform: translateY(0px);
            transform: translateY(0px);
  }
  75% {
    -webkit-transform: translateY(-3px);
            transform: translateY(-3px);
  }
  100% {
    -webkit-transform: translateY(0px);
            transform: translateY(0px);
  }
}
@-webkit-keyframes tick {
  0% {
    -webkit-transform: scale(0);
            transform: scale(0);
  }
  100% {
    -webkit-transform: scale(1);
            transform: scale(1);
  }
}
@keyframes tick {
  0% {
    -webkit-transform: scale(0);
            transform: scale(0);
  }
  100% {
    -webkit-transform: scale(1);
            transform: scale(1);
  }
}
</style></head><body>
<div class='overlay'></div>
<div class='timer'>0 seconds</div>
<div class='intro modal'>
  <div class='intro modal_inner'>
    <div class='intro modal_inner__close c_modal st'>
      x
    </div>
    <div class='intro modal_inner__title'>
      <h2>Hành tinh</h2>
    </div>
    <div class='intro modal_inner__text'>
      <p>Kéo thả các hành tinh vào vị trí đúng trong thời gian nhanh nhất có thể</p>
    </div>
    <div class='intro modal_inner__image'>
      <img src='https://s3-us-west-2.amazonaws.com/s.cdpn.io/217233/sdfsdfsdf.gif'>
    </div>
    <div class='intro modal_inner__cta c_modal'>
      <button class='st'>Bắt đầu!</button>
    </div>
  </div>
</div>
<div class='winner modal'>
  <div class='winner modal_inner'>
    <div class='winner modal_inner__title'>
      <h2>
        Tốt lắm, bạn chiến thằng với
        <span class='t'>10.00</span>
      </h2>
    </div>
    <div class='winner modal_inner__text'>
      <p>Bạn thật sự chơi rất tốt, tại sao không chia sẽ thành tích này với bạn bè</p>
    </div>
    <div class='winner modal_inner__cta'>
      <button class='tw'>
        Tweet
      </button>
      <button class='fb'>
        Chia sẻ lên facebook
      </button>
    </div>
    <div class='winner modal_inner__restart'>
    </div>
  </div>
</div>
<div class='planets'>
  <div class='planets_stars'></div>
  <div class='planets_container'>
    <div class='planets_container__title'>
      <h1>Hành Tinh</h1>
    </div>
    <div class='planets_container__title'>
      <h3>Kéo thả các hành tin vào vị trí đúng</h3>
    </div>
    <div class='planets_container__planets'>
      <div class='planet_wrap'>
        <div class='planet' data-planet='venus'>
          <img src='https://s3-us-west-2.amazonaws.com/s.cdpn.io/217233/pq_venus.png'>
        </div>
        <span>Venus</span>
      </div>
      <div class='planet_wrap'>
        <div class='planet' data-planet='earth'>
          <img src='https://s3-us-west-2.amazonaws.com/s.cdpn.io/217233/pq_earth.png'>
        </div>
        <span>Earth</span>
      </div>
      <div class='planet_wrap'>
        <div class='planet' data-planet='saturn'>
          <img src='https://s3-us-west-2.amazonaws.com/s.cdpn.io/217233/pq_saturn.png'>
        </div>
        <span>Saturn</span>
      </div>
      <div class='planet_wrap'>
        <div class='planet' data-planet='neptune'>
          <img src='https://s3-us-west-2.amazonaws.com/s.cdpn.io/217233/pq_neptune.png'>
        </div>
        <span>Neptune</span>
      </div>
      <div class='planet_wrap'>
        <div class='planet' data-planet='mercury'>
          <img src='https://s3-us-west-2.amazonaws.com/s.cdpn.io/217233/pq_mercury.png'>
        </div>
        <span>Mercury</span>
      </div>
      <div class='planet_wrap'>
        <div class='planet' data-planet='mars'>
          <img src='https://s3-us-west-2.amazonaws.com/s.cdpn.io/217233/pq_mars.png'>
        </div>
        <span>Mars</span>
      </div>
      <div class='planet_wrap'>
        <div class='planet' data-planet='jupiter'>
          <img src='https://s3-us-west-2.amazonaws.com/s.cdpn.io/217233/pq_jupiter.png'>
        </div>
        <span>Jupiter</span>
      </div>
      <div class='planet_wrap'>
        <div class='planet' data-planet='uranus'>
          <img src='https://s3-us-west-2.amazonaws.com/s.cdpn.io/217233/pq_uranus.png'>
        </div>
        <span>Uranus</span>
      </div>
    </div>
    <div class='planets_container__quiz'>
      <div class='planet_holder sun null' data-planet='sun'>
        <span>?</span>
        <div class='planet_answer'>
          <img src='https://s3-us-west-2.amazonaws.com/s.cdpn.io/217233/pq_sun.png'>
        </div>
      </div>
      <div class='planet_holder mercury' data-planet='mercury'>
        <span>?</span>
        <div class='planet_answer'>
          <img src='https://s3-us-west-2.amazonaws.com/s.cdpn.io/217233/pq_mercury.png'>
        </div>
      </div>
      <div class='planet_holder venus' data-planet='venus'>
        <span>?</span>
        <div class='planet_answer'>
          <img src='https://s3-us-west-2.amazonaws.com/s.cdpn.io/217233/pq_venus.png'>
        </div>
      </div>
      <div class='planet_holder earth' data-planet='earth'>
        <span>?</span>
        <div class='planet_answer'>
          <img src='https://s3-us-west-2.amazonaws.com/s.cdpn.io/217233/pq_earth.png'>
        </div>
      </div>
      <div class='planet_holder mars' data-planet='mars'>
        <span>?</span>
        <div class='planet_answer'>
          <img src='https://s3-us-west-2.amazonaws.com/s.cdpn.io/217233/pq_mars.png'>
        </div>
      </div>
      <div class='planet_holder jupiter' data-planet='jupiter'>
        <span>?</span>
        <div class='planet_answer'>
          <img src='https://s3-us-west-2.amazonaws.com/s.cdpn.io/217233/pq_jupiter.png'>
        </div>
      </div>
      <div class='planet_holder saturn' data-planet='saturn'>
        <span>?</span>
        <div class='planet_answer'>
          <img src='https://s3-us-west-2.amazonaws.com/s.cdpn.io/217233/pq_saturn.png'>
        </div>
      </div>
      <div class='planet_holder uranus' data-planet='uranus'>
        <span>?</span>
        <div class='planet_answer'>
          <img src='https://s3-us-west-2.amazonaws.com/s.cdpn.io/217233/pq_uranus.png'>
        </div>
      </div>
      <div class='planet_holder neptune' data-planet='neptune'>
        <span>?</span>
        <div class='planet_answer'>
          <img src='https://s3-us-west-2.amazonaws.com/s.cdpn.io/217233/pq_neptune.png'>
        </div>
      </div>
    </div>
  </div>
</div>
<script src='//production-assets.codepen.io/assets/common/stopExecutionOnTimeout-b2a7b3fe212eaa732349046d8416e00a9dec26eb7fd347590fbced3ab38af52e.js'></script><script src='//cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script><script src='//cdnjs.cloudflare.com/ajax/libs/jqueryui/1.11.2/jquery-ui.min.js'></script>
<script>// Init draggable

var planet = '.planet'; // Planet element
var holder = '.planet_holder'; // Holder element
var planets = 8;
var correct = 0;

$(planet).draggable({
  revert:true
})

// Init droppable

$(holder).droppable({
  hoverClass: "ui-state-hover",
  drop:function(event, ui){
    var dropped = $(this).data('planet')
    if($(ui.draggable).data('planet') == dropped){
      setTimeout(function(){
        $(ui.draggable).append('<div class="tick"><i class="icon ion-checkmark-round"></i></div>')
      },500)
      $(ui.draggable).find('img').css('opacity','.12')
      $(this).find('.planet_answer img').addClass('scale');
      $(this).find('.planet_answer').parent().css('border','none');
      $(ui.draggable).next().addClass('answered')
      correct ++;
    } else {
    }
    if(correct == planets){
      show_modal('winner')
      clearTimeout(timer)
      $('.t').html(time)
    }
  }
})


var timer = 0;


function show_modal(modal){
  $('.' + modal).show();
  $('.overlay').show();
}

function hide_modal(modal){
  $('.' + modal).hide();
  $('.overlay').hide();
}

function start_timer(){
  var start = new Date;
  timer = setInterval(function() {
    time = Math.floor((new Date - start) / 1000) + " seconds";
    $('.timer').html(time)
    console.log(time)
  }, 1000);
}

// Show intro modal
$('.st').click(function(){
  start_timer()
})
$(document).ready(function(){
  show_modal('intro');
})

$('.c_modal').click(function(){
  hide_modal('modal')
})

$('.ta').click(function(){
  hide_modal('modal');
  start_timer();
  correct = 0;
  $(planet).css('opacity','1')
  $('.planet_answer').hide()
  $('.answered').removeClass('answered')
  $('.planet_holder').css('border','2px dashed rgba(255, 255, 255, 0.22)')
})

var shareUrl = '';

function twShare(url, title, winWidth, winHeight) {
  var winTop = 100;
  var winLeft = 100;
  window.open('https://twitter.com/intent/tweet?text='+title, 'sharer', 'top=' + winTop + ',left=' + winLeft + ',toolbar=0,status=0,width=' + winWidth + ',height=' + winHeight);
}

    
  $('body').on('click','.tw',function(){
    twShare('https://codepen.io/jcoulterdesign/pen/fe65b4a77c18330f405702ce4205824e', 'I just completed the Planet Quiz on @codepen in ' + time + ', can you beat it? https://bit.ly/20zZ7wq %23codepen %23planetQuiz', 520, 350);
  });

$('.fb').click(function(){
  t = time;
  window.open('https://www.facebook.com/sharer/sharer.php?u=https://codepen.io/jcoulterdesign/pen/fe65b4a77c18330f405702ce4205824e&picture=http://www.jamiecoulter.co.uk/Untitled-3.png&title=Planet+quiz+on+Codepen&description=I just completed the Planet Quiz on @codepen in ' + t + ', can you beat it? https://bit.ly/20zZ7wq','targetWindow','toolbar=no,location=0,status=no,menubar=no,scrollbars=yes,resizable=yes,width=600,height=250');
})



//# sourceURL=pen.js
</script>
</body></html>